[![](https://godoc.org/github.com/jackc/pgservicefile?status.svg)](https://godoc.org/github.com/jackc/pgservicefile)
[![Build Status](https://travis-ci.org/jackc/pgservicefile.svg)](https://travis-ci.org/jackc/pgservicefile)

# pgservicefile

Package pgservicefile is a parser for PostgreSQL service files (e.g. `.pg_service.conf`).
