[![](https://godoc.org/github.com/jackc/pgpassfile?status.svg)](https://godoc.org/github.com/jackc/pgpassfile)
[![Build Status](https://travis-ci.org/jackc/pgpassfile.svg)](https://travis-ci.org/jackc/pgpassfile)

# pgpassfile

Package pgpassfile is a parser PostgreSQL .pgpass files.

Extracted and rewritten from original implementation in https://github.com/jackc/pgx.
